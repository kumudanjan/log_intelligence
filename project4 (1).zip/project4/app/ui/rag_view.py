import streamlit as st
from app.rag.engine import rag_query, ingest_sop_document
from app.observability.metrics import get_metrics, Timer


def render_rag_view():
    st.header("📚 RAG — Knowledge Base Q&A")
    st.markdown(
        "Ask questions over your **logs + SOPs** using Retrieval-Augmented Generation. "
        "Answers are grounded in retrieved context and checked for hallucinations."
    )

    tab1, tab2 = st.tabs(["🔎 Query Logs & SOPs", "📤 Upload SOP / Runbook"])

    with tab1:
        _render_query_tab()

    with tab2:
        _render_sop_upload_tab()


def _render_query_tab():
    query = st.text_input(
        "Ask a question about your logs or SOPs",
        placeholder="e.g. 'What caused the 502 errors?' or 'How do I restart the payment service?'",
    )

    col1, col2 = st.columns(2)
    with col1:
        use_logs = st.checkbox("Search logs", value=True)
    with col2:
        use_sops = st.checkbox("Search SOPs / Runbooks", value=True)
    top_k = st.slider("Top-K retrieved chunks", 2, 10, 5)

    if st.button("🔍 Ask", type="primary") and query.strip():
        collections = []
        if use_logs:
            collections.append("logs")
        if use_sops:
            collections.append("sops")

        with st.spinner("Retrieving and generating answer..."):
            with Timer("rag_query", query=query[:50]):
                result = rag_query(query, collections=collections, top_k=top_k)
            get_metrics().record("rag_hallucination_score", result["hallucination_score"])

        st.subheader("Answer")
        if result["is_safe"]:
            st.success(result["answer"])
        else:
            st.error("⚠️ Response blocked by RAI guardrail.")

        col1, col2 = st.columns(2)
        col1.metric("Grounding Score", f"{result['hallucination_score']:.0%}")
        col2.metric("Sources Retrieved", len(result["sources"]))

        with st.expander("📄 Retrieved Sources"):
            for i, src in enumerate(result["sources"], 1):
                st.markdown(f"**Source {i}** (collection: `{src.get('collection','?')}`, score: `{src.get('score',0):.2f}`)")
                st.code(src["text"][:400], language="text")


def _render_sop_upload_tab():
    st.markdown("Upload SOPs, runbooks, or knowledge base documents to enable RAG over them.")

    title = st.text_input("Document title", placeholder="e.g. Database Recovery Runbook")
    sop_text = st.text_area(
        "Paste SOP / Runbook content",
        placeholder="Paste the text of your standard operating procedure or runbook here...",
        height=300,
    )
    sop_file = st.file_uploader("Or upload a .txt file", type=["txt"])

    if sop_file:
        sop_text = sop_file.read().decode("utf-8", errors="replace")
        st.text_area("File content preview", value=sop_text[:500], height=150, disabled=True)

    if st.button("📤 Ingest into Knowledge Base", type="primary"):
        if not sop_text.strip():
            st.warning("Please provide SOP content.")
            return
        with st.spinner("Ingesting..."):
            n = ingest_sop_document(sop_text, title=title or "Unnamed SOP")
        st.success(f"✅ Ingested **{n}** chunks into the knowledge base.")
